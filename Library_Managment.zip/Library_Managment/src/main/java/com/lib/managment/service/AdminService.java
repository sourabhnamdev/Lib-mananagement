package com.lib.managment.service;

import com.lib.managment.dtos.AdminDto;

public interface AdminService {

	AdminDto addAdmin(AdminDto PublisherDto);

	
}
